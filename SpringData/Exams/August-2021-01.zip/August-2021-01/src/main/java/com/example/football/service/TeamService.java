package com.example.football.service;

//ToDo - Implement all methods
public interface TeamService {
    boolean areImported();

    String readTeamsFileContent() ;

    String importTeams() ;

}
