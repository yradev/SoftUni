package com.example.football.service;


//ToDo - Implement all methods
public interface TownService {

    boolean areImported();

    String readTownsFileContent() ;
	
	String importTowns();

}
