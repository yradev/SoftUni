package com.example.football.models.entity;

public enum Positions {
    ATT,MID,DEF;


}
